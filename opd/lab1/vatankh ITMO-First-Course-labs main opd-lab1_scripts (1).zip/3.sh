cd lab0
chmod u+w hitmontop1
ln -s mantyke3 hitmontop1/aronmantyke
cat machamp8/roselia hitmontop1/glalie > sceptile4_20
chmod u+r sceptile4 
cp sceptile4 hitmontop1/bayleef
chmod u+w electabuzz9
ln duosion2 electabuzz9/flygonduosion
chmod u+r electabuzz9/finneon electabuzz9/flygonduosion electabuzz9/espeon 
chmod u+w electabuzz9/turtwig
cp -r electabuzz9 electabuzz9/turtwig
ln -s machamp8 Copy_19
chmod u+r mantyke3
cat mantyke3 >hitmontop1/glaliemantyke
chmod u-w electabuzz9/turtwig
chmod u-w electabuzz9
chmod u-w hitmontop1
chmod u-r sceptile4
chmod u-r electabuzz9/finneon electabuzz9/flygonduosion electabuzz9/espeon
chmod u-r mantyke3
cd ..
