cd lab0
rm -f mantyke3
rm -f machamp8/gabite
rm Copy_19
rm -f electabuzz9/flygonduosion
chmod u+r machamp8
chmod u+w electabuzz9
rm -fR machamp8
rm -fR electabuzz9/turtwig
cd ..
