cd lab0
chmod 006 duosion2
chmod u=rx,g=x,o=w electabuzz9 electabuzz9/pawniard
chmod u=wx,go=x electabuzz9/finneon electabuzz9/espeon
chmod u=r,go='' electabuzz9/flygon
chmod u=rx,g=w,o=r electabuzz9/turtwig
chmod 550 hitmontop1
chmod 375 hitmontop1/oddish
chmod 006 hitmontop1/aron
chmod u=rwx,g=rx,o=w hitmontop1/tentacool
chmod u='',g=rw,o=w hitmontop1/shuppet
chmod u=rw,g=w,o-rwx hitmontop1/glalie
chmod uo=rwx,g=wx hitmontop1/bayleef
chmod 335 machamp8
chmod 400 machamp8/gabite
chmod 400 machamp8/roselia
chmod 006 machamp8/kricketune
chmod 004 machamp8/tyrogue
chmod 004 mantyke3
chmod 066 sceptile4
cd ..
