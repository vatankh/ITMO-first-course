cd lab0
wc -m t* */t* */*/t* 2>>/tmp/errors | sort -n
ls -l hitmontop1 2>> /tmp/errors | grep "^-" | sort -k6M -k7n
cat machamp8/gabite  machamp8/roselia machamp8/kricketune 2>>/tmp/errors | grep ".*[^y]$"
cat -n *e */*e */*/*e | sort -k2
cat -n *n */*n */*/*n 2>&1 | sort -rk2 
ls -ltuR 2>>/tmp/erorrs | grep "^-" | grep "\<g.*$" | head -n2
cd ..
