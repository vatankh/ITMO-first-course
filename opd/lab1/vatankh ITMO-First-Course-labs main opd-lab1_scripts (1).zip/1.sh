mkdir lab0 
cd lab0 
mkdir -p electabuzz9/pawniard electabuzz9/finneon electabuzz9/espeon electabuzz9/turtwig hitmontop1/oddish hitmontop1/tentacool hitmontop1/bayleef machamp8
cat > duosion2 <<EOF
Живет Cave Forest
EOF
cat > electabuzz9/flygon <<EOF
satk=8 sdef=8 spd=10
EOF
cat > hitmontop1/aron <<EOF
Тип
покемона STEEL ROCK
EOF
cat > hitmontop1/shuppet <<EOF
Способности Haunt Insomnia
Frisk
EOF
cat > hitmontop1/glalie <<EOF
Способности Freezing Point Inner Focus Ice
Body
EOF
cat > machamp8/gabite << EOF
satk=5 sdef=6 spd=8
EOF
cat > machamp8/roselia << EOF
Sting Stun Spore Mega Drain Leech Seed Magical Leaf Grasswhistle Giga
Drain Toxic Spikes Sweet Scent Ingrain Petal Dance Toxic Aromatherapy
Synthesis
EOF
cat > machamp8/kricketune <<EOF
satk=6 sdef=5 spd=7
EOF
cat > machamp8/tyrogue <<EOF
Ходы Body Slam
Covet Double-Edge Helping Hand Low Kick Magic Coat Mega Kick Mud-Slap
Role PLay Seismic Toss Sleep Talk Snore Swift Uproar Vacuum
Wave
EOF
cat > mantyke3 <<EOF
Ходы Air Cutter Bounce Dive Helping Hand Icy Wind
Mud-Slap Signal Beam Sleep Talk Snore Swift
Whirlpool
EOF
cat > sceptile4 <<EOF
weight=115.1 height=67.0 atk=9 def=7
EOF
cd ..
